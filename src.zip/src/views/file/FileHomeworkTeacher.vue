<template>
	<div>
		<el-button size="small" type="primary" icon="el-icon-plus" @click="createHomework">
			添加作业
		</el-button>
		<el-dialog :visible.sync="dialogFormVisible">
			<el-form :model="questionForm" ref="dataForm" label-position="left" label-width="90px"
				style="width: 400px; margin-left:50px;">
				<el-form-item label="作业主题" prop="name">
					<el-input v-model="questionForm.homeworkName"></el-input>
				</el-form-item>
				<el-form-item label="作业具体内容" prop="content">
					<el-input type="textarea" :rows="2" v-model="questionForm.homeworkContent" />
				</el-form-item>
				<el-form-item label="截至时间">
					<el-date-picker v-model="questionForm.homeworkDeadline" type="datetime" placeholder="选择日期时间">
					</el-date-picker>
				</el-form-item>



			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="dialogFormVisible = false">取消</el-button>
				<el-button type="primary" @click=" createReply() ">确定</el-button>
			</div>
		</el-dialog>

		<el-table :data="List" tooltip-effect="dark" style="width: 100%" size="medium">

			<el-table-column label="名称" width="120" align="center">
				<template slot-scope="{row}">
					{{ row.homeworkName }}
				</template>
			</el-table-column>
			<el-table-column label="作业具体要求" width="120" align="center">
				<template slot-scope="{row}">
			  {{ row.homeworkContent }}
				</template>
			</el-table-column>
			<el-table-column label="截止时间" width="220" align="center">
				<template slot-scope="{row}">
					{{ row.homeworkDeadline }}
				</template>
			</el-table-column>
			<el-table-column>
				<template slot-scope="{row}">
					<el-button type="primary" @click="jump(row)" class="detailed">查看详情</el-button>
				</template>
			</el-table-column>
		</el-table>

	</div>
</template>

<script>
	import {
		setStorage,
		getStorage
	} from '@/utils/localStorage'
	import {
		add,
		update,
		queryById,
		deleteById
	} from '@/api/getHomework'
	export default {
		name: 'FileHomework',
		data() {
			return {
				List: [],
				questionForm: {
					homeworkName: "",
					homeworkContent: "",
					homeworkDeadline: "",
				},
				dialogFormVisible: false,
			}
		},
		methods: {
			initHomeworkList() {
				this.courseId = JSON.parse(getStorage("courseInfo")).courseId
				const data = {
					courseId: this.courseId
				}
				if (data) {
					queryById(data).then(res => {
						this.List = res.datas
						console.log(this.List)
					})
				}

			},
			createHomework() {
				this.dialogFormVisible = true;
			},
			createReply() {

				this.courseId = JSON.parse(getStorage("courseInfo")).courseId
				const data = {
					courseId: this.courseId,
					homeworkName: this.questionForm.homeworkName,
					homeworkContent: this.questionForm.homeworkContent,
					homeworkDeadline: this.questionForm.homeworkDeadline
				}
				console.log(data)
				if (data) {
					add(data).then(res => {

						this.List = res.datas
						this.$message({
							message: '作业布置成功',
							type: 'success'
						});
						this.initHomeworkList();
					})
				}
				this.dialogFormVisible = false
			},
			handleCreate() {
				this.questionForm = {
					questionContent: this.name,
					correctAnswer: "",
				};
				this.dialogFormVisible = true;
			},
			jump(row) {
				console.log(row)
				setStorage("homeworkId", JSON.stringify(row.homeworkId))
				this.$router.push('/file/file-homeworkTeacherDetail')
		 },
		},

		mounted() {
			this.$nextTick(() => {
				this.initHomeworkList();
			})
		},
	}
</script>

<style>
</style>

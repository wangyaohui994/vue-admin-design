import { asyncRoutes } from './routes'
import {
		getStorage,
		setStorage
	} from '@/utils/localStorage'
	
	asyncRouterMap.filter()

import FlowPanelDetail from './FlowPanelDetail'
import KoniPanelDetail from './FlowPanelDetail'
import MindPanelDetail from './MindPanelDetail'

export { FlowPanelDetail, KoniPanelDetail, MindPanelDetail }

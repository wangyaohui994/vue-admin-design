<template>
  <div class="section-main-wrapper" />
</template>

<script>
export default {
  name: 'SectionMain'
}
</script>

<style lang="less">
.section-main-wrapper {}
</style>
